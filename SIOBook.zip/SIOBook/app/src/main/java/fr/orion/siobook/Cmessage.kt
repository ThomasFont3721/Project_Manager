package fr.orion.siobook

class Cmessage(
        var idM: String ="",
        var idUIPSM: String ="",
        var idPM: String ="",
        var idUSM: String ="",
        var nameUIPSM: String ="",
        var contentM: String ="",
        var millisM: Long =0,
        var urlimgUIP: String ="",
        var typeMsg: String =""
)