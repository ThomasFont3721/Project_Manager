package fr.orion.siobook

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.recyclerview.widget.LinearLayoutManager
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.OrientationHelper
import com.google.firebase.Timestamp
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.android.synthetic.main.activity_message_project.*
import kotlinx.android.synthetic.main.z_menu_home_project.*
import kotlinx.android.synthetic.main.z_toolbar.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.*

@Suppress("PLUGIN_WARNING")
class Message_project : AppCompatActivity() {

    private val listmsg: ArrayList<Cmessage> = arrayListOf()
    private val listmsgID: ArrayList<String> = arrayListOf()

    private var selectedPhotoUri: ArrayList<ByteArray> = arrayListOf()
    private var MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE =101
    private var MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE =101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message_project)
        FULLSCREEN(window)
        initialise()
        toolbar()
        getMessage()
        onclickMSG()
        onclicksend()
        setupPermissionsRead()
        setupPermissionsWrite()
        getimage()
        RV_message_project_listImgInMsg.layoutManager = LinearLayoutManager(this@Message_project, OrientationHelper.HORIZONTAL, false)
        RV_message_project_listImgInMsg.visibility =View.GONE
        deleteImg()
    }


    private fun deleteImg(){
        RV_message_project_listImgInMsg.addOnItemClickListener(object : OnItemClickListener {
            override fun onItemClicked(position: Int, view: View) {
                selectedPhotoUri.removeAt(position)
                RV_message_project_listImgInMsg.adapter =MyAdapterImgInMsg(selectedPhotoUri)
                if (selectedPhotoUri.size ==0){
                    RV_message_project_listImgInMsg.visibility =View.GONE
                }
            }
        })
    }

    private fun getimage(){
        CL_message_project_addS.setOnClickListener {
            val intent =Intent(Intent.ACTION_PICK)
            intent.type ="image/*"
            startActivityForResult(intent, 0)
        }
    }
    private fun compressBitmap(bitmap:Bitmap, quality:Int): ByteArray{

        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, bos)
        return bos.toByteArray()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0 && resultCode == Activity.RESULT_OK && data !=null){

            val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, data.data)
            val img =compressBitmap(bitmap = bitmap, quality = 20)
            //val drawable = BitmapDrawable(resources, BitmapFactory.decodeByteArray(img, 0, img.size))
            selectedPhotoUri.add(img)
            RV_message_project_listImgInMsg.adapter =MyAdapterImgInMsg(listIMG = selectedPhotoUri)
            RV_message_project_listImgInMsg.visibility =View.VISIBLE
        }
    }

    private fun setupPermissionsRead() {
        val permission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)

        if (permission != PackageManager.PERMISSION_GRANTED) {
            Log.i(FLAG, "Permission to record denied")
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                            Manifest.permission.READ_EXTERNAL_STORAGE)) {
                val builder = AlertDialog.Builder(this)
                builder.setMessage("Permission to access the storage is required for this application.")
                        .setTitle("Permission required")

                builder.setPositiveButton("OK"
                ) { _, _ ->
                    Log.i(FLAG, "Clicked")
                    makeRequestRead()
                }

                val dialog = builder.create()
                dialog.show()
            } else {
                makeRequestRead()
            }
        }
    }
    private fun makeRequestRead() {
        ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE)
    }
    private fun setupPermissionsWrite() {
        val permission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)

        if (permission != PackageManager.PERMISSION_GRANTED) {
            Log.i(FLAG, "Permission to record denied")
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                val builder = AlertDialog.Builder(this)
                builder.setMessage("Permission to access the storage is required for this application.")
                        .setTitle("Permission required")

                builder.setPositiveButton("OK"
                ) { _, _ ->
                    Log.i(FLAG, "Clicked")
                    makeRequestWrite()
                }

                val dialog = builder.create()
                dialog.show()
            } else {
                makeRequestWrite()
            }
        }
    }
    private fun makeRequestWrite() {
        ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode){
            MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE ->
                if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {

                    Log.i(FLAG, "Permission has been denied by user")
                } else {
                    Log.i(FLAG, "Permission has been granted by user")
                }
            MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE ->
                if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {

                    Log.i(FLAG, "Permission has been denied by user")
                } else {
                    Log.i(FLAG, "Permission has been granted by user")
                }
        }
    }

    private fun onclicksend(){
        LL_message_project_send.setOnClickListener {
            val date = Calendar.getInstance()
            date.timeInMillis = Timestamp.now().seconds*1000L
            when {
                selectedPhotoUri.isEmpty() && ET_message_project_msg.text.toString().isNotEmpty() -> {
                    val msg =Cmessage(idM = "",idUIPSM = MYIDUIP, idPM = CIDPROJECT, idUSM = CUSER.idU, nameUIPSM = CUSER.fNameU, contentM = ET_message_project_msg.text.toString(), millisM = date.timeInMillis, urlimgUIP = CUSER.imgUrlU, typeMsg = SMS)
                    ADDSMS(message = msg)
                    ET_message_project_msg.setText("")
                }
                selectedPhotoUri.isNotEmpty() && ET_message_project_msg.text.toString().isNotEmpty() -> {
                    val msg =Cmessage(idM = "",idUIPSM = MYIDUIP, idPM = CIDPROJECT, idUSM = CUSER.idU, nameUIPSM = CUSER.fNameU, contentM = ET_message_project_msg.text.toString(), millisM = date.timeInMillis, urlimgUIP = CUSER.imgUrlU, typeMsg = SMS)
                    ADDSMS(message = msg)
                    ET_message_project_msg.setText("")

                    val msgWI =Cmessage(idM = "",idUIPSM = MYIDUIP, idPM = CIDPROJECT, idUSM = CUSER.idU, nameUIPSM = CUSER.fNameU, millisM = date.timeInMillis, urlimgUIP = CUSER.imgUrlU, typeMsg = MMS)
                    selectedPhotoUri.forEach {
                        ADDMMS(message = msgWI, selectedPhoto = it)
                    }
                    selectedPhotoUri.clear()
                    RV_message_project_listImgInMsg.visibility =View.GONE
                }
                selectedPhotoUri.isNotEmpty() && ET_message_project_msg.text.toString().isEmpty() -> {
                    val msg =Cmessage(idM = "",idUIPSM = MYIDUIP, idPM = CIDPROJECT, idUSM = CUSER.idU, nameUIPSM = CUSER.fNameU, millisM = date.timeInMillis, urlimgUIP = CUSER.imgUrlU, typeMsg = MMS)
                    selectedPhotoUri.forEach {
                        ADDMMS(message = msg, selectedPhoto = it)
                    }
                    selectedPhotoUri.clear()
                    RV_message_project_listImgInMsg.visibility =View.GONE
                }
            }
        }
    }

    private fun getMessage(){
        val dateNow = Calendar.getInstance()
        dateNow.timeInMillis = Timestamp.now().seconds*1000L
        val date = Calendar.getInstance()
        DB.collection(MESSAGE)
                .whereEqualTo(IDPM, CIDPROJECT)
                .orderBy(MILLIS, ASC)
                //.limit(100)
                .addSnapshotListener(EventListener<QuerySnapshot> {snapshot, error ->
                    if (error != null){
                        LOG("error message ::: $error")
                        return@EventListener
                    }

                    listmsg.clear()
                    //LISTLLM.clear()
                    listmsgID.clear()
                    for (message in snapshot!!){
                        date.timeInMillis =message.toObject(Cmessage::class.java).millisM
                        if (date.get(Calendar.MONTH) == dateNow.get(Calendar.MONTH)){
                            listmsg.add(message.toObject(Cmessage::class.java))
                            listmsgID.add(message.toObject(Cmessage::class.java).idM)
                        }
                    }
                    if (listmsg.size > 0){
                        LOG("Mise en place liste Message")
                        //RV_messageProject.layoutManager =LinearLayoutManager(this@Message_project, OrientationHelper.VERTICAL, true)
                        //RV_messageProject.adapter =MyAdapterMessage_Project(context = this@Message_project, listM = listmsg, rv = RV_messageProject)
                        LV_messageProject.adapter =MyListAdapterMessage_Project(context = this@Message_project, listID = listmsgID, listM = listmsg, lv = LV_messageProject)
                    }
                })
    }

    private fun onclickMSG(){
         /*RV_messageProject.addOnItemClickListener(object : OnItemClickListener {
             override fun onItemClicked(position: Int, view: View) {
                 val messages =listmsg[position]
                 if (messages.typeMsg == MMS){
                     LISTALLIMG.getImg(messages.idM)
                     startActivity(Intent(this@Message_project, FullScreenMMS::class.java).apply {})
                     overridePendingTransition(R.anim.hide_to_show, R.anim.show_to_hide)
                 }
             }
         })*/
        LV_messageProject.setOnItemClickListener { _, _, position, _ ->
            val messages =listmsg[position]
            if (messages.typeMsg == MMS){
                LISTALLIMG.getImg(messages.idM)
                startActivity(Intent(this@Message_project, FullScreenMMS::class.java).apply {})
                overridePendingTransition(R.anim.hide_to_show, R.anim.show_to_hide)
            }
        }
        LV_messageProject.setOnItemLongClickListener { _, _, position, _ ->
            val messages =listmsg[position]
            if (messages.typeMsg == MMS){
                LISTALLIMG.getImg(messages.idM)
                IV_message_project_IMGShowBS.setImageBitmap(IMGFULLSCREEN)
                CL_message_project_saveImg.visibility =View.VISIBLE
            }
            true
        }
        TV_message_project_saveOK.setOnClickListener {
            if (saveFile()){
                Toast.makeText(this@Message_project, "Image save", Toast.LENGTH_SHORT).show()
            }
            else {
                Toast.makeText(this@Message_project, "An error has occurred", Toast.LENGTH_SHORT).show()
            }
            CL_message_project_saveImg.visibility =View.GONE
        }
        TV_message_project_saveCancel.setOnClickListener {
            CL_message_project_saveImg.visibility =View.GONE
        }
    }

    fun saveFile(): Boolean{
        val myDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + File.separator + "project_manager/")
        myDir.mkdirs()
        val file = File (myDir, "IMG_$IDIMGFULLSCREEN.jpg")
        LOG("Chemin ::: $file")
        if (file.exists ()) file.delete()
        return try {
            val out = FileOutputStream(file)
            IMGFULLSCREEN.compress(Bitmap.CompressFormat.JPEG, 100, out)
            out.close()
            MediaScannerConnection.scanFile(this@Message_project, arrayOf(file.absolutePath), null) { path, uri ->
                LOG("Scanned ::: $path")
                LOG("uri ::: $uri")
            }
            true

        } catch (e: Exception) {
            LOG("ERROR ::: $e")
            false
        }
    }

    private fun initialise(){
        IV_menu_home_project_chat.setImageResource(R.drawable.ic_chat_white_24dp)
        bottomMenu()
    }
    private fun bottomMenu(){
        LL_menu_home_project_listuip.setOnClickListener {
            startActivity(Intent(this@Message_project, Home_Project::class.java).apply {})
            overridePendingTransition(R.anim.no_anim, R.anim.no_anim)
            finish()
        }
        LL_menu_home_project_chat.setOnClickListener {
            startActivity(Intent(this@Message_project, Message_project::class.java).apply {})
            overridePendingTransition(R.anim.no_anim, R.anim.no_anim)
            finish()
        }
    }
    private fun toolbar(){
        IV_z_toolbar_modify.visibility =View.GONE
        IV_z_toolbar_log_out.visibility =View.GONE
        IV_z_toolbar_add.visibility =View.GONE
        IV_z_toolbar_search.visibility =View.GONE
        TV_z_toolbar_title.text = CPROJECT.nameP
    }
    override fun onBackPressed() {
        startActivity(Intent(this@Message_project, Home_Project::class.java).apply {})
        overridePendingTransition(R.anim.no_anim, R.anim.no_anim)
        finish()
    }
}
