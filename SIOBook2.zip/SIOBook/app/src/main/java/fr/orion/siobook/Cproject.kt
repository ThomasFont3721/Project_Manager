package fr.orion.siobook

class Cproject(
    var nameP: String ="",
    var yearP: Int =0,
    var monthP: Int =0,
    var dayP: Int =0,
    var hourP: Int =0,
    var minuteP: Int =0,
    var secondP: Int =0,
    var ratioP: Int =0,
    var state: Int =1,
    var memberP: ArrayList<String> =ArrayList(),
    var idP: String =""
)