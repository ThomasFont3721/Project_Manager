package fr.orion.siobook

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class task_list_user_in_project : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_list_user_in_project)
        FULLSCREEN(window)

    }
}
