package fr.orion.siobook

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_add_user_in_project.*
import kotlinx.android.synthetic.main.z_toolbar.*

class add_user_in_project : AppCompatActivity() {

    private val listAllUser: ArrayList<Cuser> = arrayListOf()

    private val listnothing: ArrayList<String> = arrayListOf()
    private var listRole: ArrayList<String> = arrayListOf("Project manager","Developer","Disigner","Class creator","Function creator","Undefined")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_user_in_project)
        FULLSCREEN(window)
        toolbar()
        getuser()
        B_add_UIP_Add.setOnClickListener {
            val _nameU =ACTV_add_UIP_name.text.toString()

            if(TextUtils.isEmpty(_nameU.trim())){
                ACTV_add_UIP_name.error ="Enter a name for this contributor"
                return@setOnClickListener
            }
        }
    }
    private fun itemlist(){
        ACTV_add_UIP_name.setAdapter(MyAdapterNameList(this@add_user_in_project, email = listnothing, user = listAllUser))
        ACTV_add_UIP_name.threshold = 0
        ACTV_add_UIP_name.onFocusChangeListener = View.OnFocusChangeListener{ _, b ->
            if(b){ ACTV_add_UIP_name.showDropDown() }
        }
        ACTV_add_UIP_role.setAdapter(MyAdapterRoleList(this@add_user_in_project, name = listRole))
        ACTV_add_UIP_role.threshold = 0
        ACTV_add_UIP_role.onFocusChangeListener = View.OnFocusChangeListener{ _, b ->
            if(b){ ACTV_add_UIP_role.showDropDown() }
        }
    }

    private fun getuser(){
        DB.collection(USER)
                .get()
                .addOnCompleteListener { read ->
                    if (read.isSuccessful) {
                        for (user in read.result!!) {
                            listnothing.add(user.toObject(Cuser::class.java).emailU)
                            listAllUser.add(user.toObject(Cuser::class.java))
                        }
                        itemlist()
                    } else {
                        Toast.makeText(this, "error", Toast.LENGTH_SHORT).show()
                    }
                }
    }

    private fun toolbar(){
        IV_z_toolbar_modify.visibility =View.GONE
        IV_z_toolbar_add.visibility =View.GONE
        IV_z_toolbar_log_out.visibility =View.GONE
        TV_z_toolbar_title.text ="Add a contributor"
    }

    override fun onBackPressed() {
        startActivity(Intent(this@add_user_in_project, Home_Project::class.java).apply {})
        overridePendingTransition(R.anim.no_anim, R.anim.no_anim)
        finish()
    }
}
