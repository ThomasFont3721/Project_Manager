package fr.orion.siobook

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.QuerySnapshot

class Home_UIP : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_uip)
        FULLSCREEN(window)

        DB.collection(USERINPROJECT)
                .whereEqualTo(IDUIP, CIDUIP)
                .addSnapshotListener(EventListener<QuerySnapshot> { snapshots, e ->
                    if (e != null) {
                        LOG("error uip ::: $e")
                        return@EventListener
                    }
                    for (uip in snapshots!!) {
                        LOG("email ::: ${uip.toObject(CUserInProject::class.java).emailUIP}")
                    }
                })
    }
}
